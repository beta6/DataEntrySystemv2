<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Learn2 extends Theme
{

}
